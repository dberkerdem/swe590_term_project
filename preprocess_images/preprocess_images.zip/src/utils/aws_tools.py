"""aws_tools script contains utility functions to perform read and write operations to AWS"""
import boto3


def boto3_connect(connect_to: str):
    """
    Implementation of boto3 client wrapper.
    Creates a boto3 connection client object to the AWS resource of interest, and pass the object to wrapped function.
    @param connect_to: a str, that corresponds to the resource name to the connection client to be established
    @return: a decorator
    """

    def decorator(func):
        def wrapper(*args, **kwargs):
            conn = boto3.client(connect_to)
            return func(conn=conn, *args, **kwargs)

        return wrapper

    return decorator


@boto3_connect(connect_to='s3')
def list_objects_in_s3(conn: object, bucket: str) -> list:
    """

    :param conn: A low-level client representing Amazon Resources
    :param bucket: The name of the bucket containing the objects
    :return:
    """
    objects = conn.list_objects(
        Bucket=bucket,
    )
    # Return the list of contents
    return object.get('Contents')


@boto3_connect(connect_to='s3')
def read_image_from_s3(conn: object, fileobj: object, bucket: str, key: str) -> None:
    """
    Implementation of uploading images to s3 bucket
    :param conn: A low-level client representing Amazon Resources
    :param fileobj: A file-like object to upload. At a minimum, it must implement the read method, and must return bytes
    :param bucket: The name of the bucket to upload to
    :param key: The name of the key to upload to
    :return: None, void function
    """
    conn.upload_fileobj(Fileobj=fileobj, Bucket=bucket, Key=key)
    # Close to connection to prevent bottleneck
    conn.close()
