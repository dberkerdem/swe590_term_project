

def preprocess_image():
    pass
